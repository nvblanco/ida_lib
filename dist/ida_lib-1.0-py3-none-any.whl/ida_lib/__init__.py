__version__ = "0.1.0"
__author__ = 'Raquel Vilas'

__all__ = ['core', 'image_augmentation', 'operations', 'visualization', 'global_parameters']
