__all__ = ['pipeline', 'pipeline_functional', 'pipeline_geometric_ops', 'pipeline_pixel_ops', 'pipeline_local_ops']
